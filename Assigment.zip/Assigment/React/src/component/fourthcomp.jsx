import React from "react";

class FourthComp extends React.Component{
    render(){
        return <h1>Fourth Component.</h1>
    }
}
export default FourthComp;