import React from "react";

class FirstComp extends  React.Component{
    render(){
        return <h1 style={{fontSize:'100px',color:'magento'}}>First Component.</h1>;
    }
}export default FirstComp;