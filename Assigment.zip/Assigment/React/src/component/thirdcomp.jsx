import React from "react";
import '../CSS/external.css';

class ThirdComp extends React.Component{
    render(){
        return <h1 className="ExternalCss">Third Component.</h1>
    }
}
export default ThirdComp;