type chars = string;
let message: chars;
message="I love my country.";
console.log(message);


type alphanumeric = string | number;
let input: alphanumeric;
input = 1; 
input = "I love my country.";