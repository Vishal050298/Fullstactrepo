// Number.
// String.
// Boolean.
// Void.
// null.
// Undefined.
// Nan.

class FirstCLS { 
    demoFun():void { 
       console.log("Hello Guys..!!") 
    } 
 } 
 var obj = new FirstCLS(); 
 obj.demoFun();