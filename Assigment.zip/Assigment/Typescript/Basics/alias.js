var message;
message = "God Is Great.";
console.log(message);
var input;
input = 1;
input = "God Is Great.";
