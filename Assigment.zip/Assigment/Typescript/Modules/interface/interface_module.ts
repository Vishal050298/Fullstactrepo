interface IValidator {
    isValidStr(s: string,regex): boolean
    
}

export { IValidator };